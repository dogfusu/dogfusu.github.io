# FusuMother-Mourning-Hall
欢迎来到扶苏妈妈-FusuMother的奇妙灵堂

很抱歉，由于Fusu过度的恶心人

我们不得不为其母亲设立灵堂，以纪念扶苏妈妈-FusuMother的死去。

扶苏母亲的死去，应该是大多数人不能接受的结果。

请允许我们在此献上最后的告别，以此纪念其在DDTank留下的回忆与足迹。
